# GENERATED VERSION FILE
# TIME: Thu Sep 11 18:38:59 2025
__version__ = '1.2.0+unknown'
short_version = '1.2.0'
version_info = (1, 2, 0)
