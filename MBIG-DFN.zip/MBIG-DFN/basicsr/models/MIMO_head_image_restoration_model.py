# ------------------------------------------------------------------------
# Copyright (c) 2022 megvii-model. All Rights Reserved.
# ------------------------------------------------------------------------
# Modified from BasicSR (https://github.com/xinntao/BasicSR)
# Copyright 2018-2020 BasicSR Authors
# ------------------------------------------------------------------------
import importlib
import torch
import torch.nn.functional as F
from collections import OrderedDict
from copy import deepcopy
from os import path as osp
from tqdm import tqdm

from basicsr.models.archs import define_network
from basicsr.models.base_model import BaseModel
from basicsr.utils import get_root_logger, imwrite, tensor2img
from basicsr.utils.dist_util import get_dist_info
import numpy as np

from basicsr.loss.reblur import ReBlurImage
from basicsr.models.losses import PSNRLoss, L1Loss

loss_module = importlib.import_module('basicsr.models.losses')
metric_module = importlib.import_module('basicsr.metrics')


class MIMOHeadImageRestorationModel(BaseModel):
    """Base Deblur model for single image deblur."""

    def __init__(self, opt):
        super(MIMOHeadImageRestorationModel, self).__init__(opt)

        # define network
        self.net_g = define_network(deepcopy(opt['network_g']))
        self.net_g = self.model_to_device(self.net_g)

        # load pretrained models
        load_path = self.opt['path'].get('pretrain_network_g', None)
        if load_path is not None:
            self.load_network(self.net_g, load_path,
                              self.opt['path'].get('strict_load_g', True), param_key=self.opt['path'].get('param_key', 'params'))

        if self.is_train:
            self.init_training_settings()

        self.scale = int(opt['scale'])
        self.reblur = ReBlurImage()   #--------
        self.psnr_loss = PSNRLoss()
        self.l1_loss = L1Loss()

    def init_training_settings(self):
        self.net_g.train()
        train_opt = self.opt['train']

        # define losses
        if train_opt.get('pixel_opt'):
            pixel_type = train_opt['pixel_opt'].pop('type')
            cri_pix_cls = getattr(loss_module, pixel_type)
            self.cri_pix = cri_pix_cls(**train_opt['pixel_opt']).to(
                self.device)
        else:
            self.cri_pix = None

        if train_opt.get('perceptual_opt'):
            percep_type = train_opt['perceptual_opt'].pop('type')
            cri_perceptual_cls = getattr(loss_module, percep_type)
            self.cri_perceptual = cri_perceptual_cls(
                **train_opt['perceptual_opt']).to(self.device)
        else:
            self.cri_perceptual = None

        if self.cri_pix is None and self.cri_perceptual is None:
            raise ValueError('Both pixel and perceptual losses are None.')

        # set up optimizers and schedulers
        self.setup_optimizers()
        self.setup_schedulers()

    def setup_optimizers(self):
        train_opt = self.opt['train']
        optim_params = []

        for k, v in self.net_g.named_parameters():
            if v.requires_grad:
                #         if k.startswith('module.offsets') or k.startswith('module.dcns'):
                #             optim_params_lowlr.append(v)
                #         else:
                # if k.startswith('module.event_preprocessing'):
                optim_params.append(v)
            # else:
            #     logger = get_root_logger()
            #     logger.warning(f'Params {k} will not be optimized.')
        # print(optim_params)
        # ratio = 0.1

        optim_type = train_opt['optim_g'].pop('type')
        if optim_type == 'Adam':
            self.optimizer_g = torch.optim.Adam([{'params': optim_params}],
                                                **train_opt['optim_g'])
        elif optim_type == 'SGD':
            self.optimizer_g = torch.optim.SGD(optim_params,
                                               **train_opt['optim_g'])
        elif optim_type == 'AdamW':
            self.optimizer_g = torch.optim.AdamW([{'params': optim_params}],
                                                 **train_opt['optim_g'])
            pass
        else:
            raise NotImplementedError(
                f'optimizer {optim_type} is not supperted yet.')
        self.optimizers.append(self.optimizer_g)

    def feed_data(self, data, is_val=False):
        self.lq = data['lq'].to(self.device)
        _, _, h, w = self.lq.size()
        # print(self.lq.size())
        self.lq = self.lq[:, :, 0:int(h // 4 * 4), 0:int(w // 4 * 4)]
        # print(self.lq.size())
        if 'gt' in data:
            self.gt = data['gt'].to(self.device)
            self.gt = self.gt[:, :, 0:int(h // 4 * 4), 0:int(w // 4 * 4)]

    def grids(self):
        b, c, h, w = self.gt.size()
        self.original_size = (b, c, h, w)

        assert b == 1
        if 'crop_size_h' in self.opt['val']:
            crop_size_h = self.opt['val']['crop_size_h']
        else:
            crop_size_h = int(self.opt['val'].get('crop_size_h_ratio') * h)

        if 'crop_size_w' in self.opt['val']:
            crop_size_w = self.opt['val'].get('crop_size_w')
        else:
            crop_size_w = int(self.opt['val'].get('crop_size_w_ratio') * w)

        crop_size_h, crop_size_w = crop_size_h // self.scale * self.scale, crop_size_w // self.scale * self.scale
        # adaptive step_i, step_j
        num_row = (h - 1) // crop_size_h + 1
        num_col = (w - 1) // crop_size_w + 1

        import math
        step_j = crop_size_w if num_col == 1 else math.ceil((w - crop_size_w) / (num_col - 1) - 1e-8)
        step_i = crop_size_h if num_row == 1 else math.ceil((h - crop_size_h) / (num_row - 1) - 1e-8)

        scale = self.scale
        step_i = step_i // scale * scale
        step_j = step_j // scale * scale

        parts = []
        idxes = []

        i = 0  # 0~h-1
        last_i = False
        while i < h and not last_i:
            j = 0
            if i + crop_size_h >= h:
                i = h - crop_size_h
                last_i = True

            last_j = False
            while j < w and not last_j:
                if j + crop_size_w >= w:
                    j = w - crop_size_w
                    last_j = True
                parts.append(self.lq[:, :, i // scale:(i + crop_size_h) // scale, j // scale:(j + crop_size_w) // scale])
                idxes.append({'i': i, 'j': j})
                j = j + step_j
            i = i + step_i

        self.origin_lq = self.lq
        self.lq = torch.cat(parts, dim=0)
        self.idxes = idxes

    def grids_inverse(self):
        b, c, h, w = self.original_size
        n_heads = self.output.size()[1]
        preds = torch.zeros(b, n_heads, c, h, w)

        count_mt = torch.zeros((b, 1, 1, h, w))
        if 'crop_size_h' in self.opt['val']:
            crop_size_h = self.opt['val']['crop_size_h']
        else:
            crop_size_h = int(self.opt['val'].get('crop_size_h_ratio') * h)

        if 'crop_size_w' in self.opt['val']:
            crop_size_w = self.opt['val'].get('crop_size_w')
        else:
            crop_size_w = int(self.opt['val'].get('crop_size_w_ratio') * w)

        crop_size_h, crop_size_w = crop_size_h // self.scale * self.scale, crop_size_w // self.scale * self.scale

        for cnt, each_idx in enumerate(self.idxes):
            i = each_idx['i']
            j = each_idx['j']
            preds[0, :, :, i: i + crop_size_h, j: j + crop_size_w] += self.output[cnt]
            count_mt[0, 0, 0, i: i + crop_size_h, j: j + crop_size_w] += 1.

        self.output = (preds / count_mt).to(self.device)
        self.lq = self.origin_lq

    def optimize_parameters(self, current_iter, tb_logger):
        self.optimizer_g.zero_grad()

        if self.opt['train'].get('mixup', False):
            self.mixup_aug()

        preds, offsets = self.net_g(self.lq)

        self.output = preds[-1]

        l_total = 0
        loss_dict = OrderedDict()
        # pixel loss
        if self.cri_pix:
            l_pix = 0.
            l_pix += self.cri_pix(preds, self.gt)

            # ----------------------------------------------------ReblurLoss
            lq_4 = F.interpolate(self.lq, scale_factor=0.25, mode='bilinear')
            gt_4 = F.interpolate(self.gt, scale_factor=0.25, mode='bilinear')
            reblur_image = self.reblur(lq_4, gt_4, offsets['offset'], offsets['weight'])
            # l_reblur = self.psnr_loss(reblur_image, lq_4) * 0.01
            l_reblur = self.l1_loss(reblur_image, lq_4) * 0.01

            # print('l pix ... ', l_pix)
            l_total += l_pix
            l_total += l_reblur
            loss_dict['l_pix'] = l_pix
            loss_dict['l_reblur'] = l_reblur

        # perceptual loss
        if self.cri_perceptual:
            l_percep, l_style = self.cri_perceptual(self.output, self.gt)
            #
            if l_percep is not None:
                l_total += l_percep
                loss_dict['l_percep'] = l_percep
            if l_style is not None:
                l_total += l_style
                loss_dict['l_style'] = l_style

        l_total = l_total + 0. * sum(p.sum() for p in self.net_g.parameters())

        l_total.backward()
        use_grad_clip = self.opt['train'].get('use_grad_clip', True)
        if use_grad_clip:  # 梯度裁剪
            torch.nn.utils.clip_grad_norm_(self.net_g.parameters(), 0.01)
        self.optimizer_g.step()

        self.log_dict = self.reduce_loss_dict(loss_dict)

    def test(self):
        self.net_g.eval()
        with torch.no_grad():
            n = len(self.lq)
            outs = []
            m = self.opt['val'].get('max_minibatch', n)
            i = 0
            while i < n:
                j = i + m
                if j >= n:
                    j = n
                pred, offsets = self.net_g(self.lq[i:j])
                if isinstance(pred, list):
                    pred = pred[-1]
                outs.append(pred.detach().cpu())
                i = j

            self.output = torch.cat(outs, dim=0)
            self.offsets = offsets
        self.net_g.train()

    def dist_validation(self, dataloader, current_iter, tb_logger, save_img, rgb2bgr, use_image):
        dataset_name = dataloader.dataset.opt['name']
        with_metrics = self.opt['val'].get('metrics') is not None
        # ------------------------------------------------------
        n_heads = self.opt['network_g'].get('n_heads', 4)
        if self.opt['network_g'].get('combinate_heads', False):  # 如果启动
            n_heads = (n_heads + 1) * n_heads // 2 + 1
        # -------------------------------------------------------
        if with_metrics:  # 用来存储每个指标的累计值、最佳值和最差值
            self.metric_results = {
                metric: np.zeros(n_heads)
                for metric in self.opt['val']['metrics'].keys()
            }
            self.metric_results.update({
                metric + '_best': 0
                for metric in self.opt['val']['metrics'].keys()
            })
            self.metric_results.update({
                metric + '_worst': 0
                for metric in self.opt['val']['metrics'].keys()
            })

        rank, world_size = get_dist_info()
        if rank == 0:
            pbar = tqdm(total=len(dataloader), unit='image')

        cnt = 0

        for idx, val_data in enumerate(dataloader):
            if idx % world_size != rank:
                continue

            img_name = osp.splitext(osp.basename(val_data['lq_path'][0]))[0]

            # print("**********")
            self.feed_data(val_data, is_val=True)
            # print("^^^^^^^^^^^^^^^^^^^^")
            if self.opt['val'].get('grids', False):
                self.grids()

            self.test()

            if self.opt['val'].get('grids', False):
                self.grids_inverse()

            visuals = self.get_current_visuals()
            if use_image or save_img:
                sr_img_list = [tensor2img([visuals['result'][h]], rgb2bgr=rgb2bgr) for h in range(n_heads)]
                if 'gt' in visuals:
                    gt_img = tensor2img([visuals['gt']], rgb2bgr=rgb2bgr)
                    del self.gt

            # tentative for out of GPU memory
            del self.lq
            del self.output
            torch.cuda.empty_cache()

            save_best = -1  # 改成了一堆屎山

            # -------------------*******************------------------------------------
            if with_metrics:
                # calculate metrics
                opt_metric = deepcopy(self.opt['val']['metrics'])
                if use_image:
                    for name, opt_ in opt_metric.items():
                        metric_type = opt_.pop('type')
                        _r = getattr(
                            metric_module, metric_type)(sr_img_list, gt_img, **opt_)
                        if save_best == -1:
                            save_best = _r[3]
                        self.metric_results[name] += _r[0]
                        self.metric_results[name + '_best'] += _r[1]
                        self.metric_results[name + '_worst'] += _r[2]
                else:
                    for name, opt_ in opt_metric.items():
                        metric_type = opt_.pop('type')
                        _r = getattr(
                            metric_module, metric_type)(visuals['result'], visuals['gt'], **opt_)
                        self.metric_results[name] += _r[0]
                        self.metric_results[name + '_best'] += _r[1]
                        self.metric_results[name + '_worst'] += _r[2]

            if save_img:
                if self.opt['is_train']:
                    for h in range(n_heads):
                        save_img_path = osp.join(
                            self.opt['path']['visualization'], img_name,
                            f'{img_name}_{current_iter}_h{h}.png')
                        imwrite(sr_img_list[h], save_img_path)
                    save_gt_img_path = osp.join(
                        self.opt['path']['visualization'], img_name,
                        f'{img_name}_{current_iter}_gt.png')
                    imwrite(gt_img, save_gt_img_path)
                else:
                    if save_best != -1:
                        # save_img_path = osp.join(self.opt['path']['visualization'], dataset_name, img_name.split('-')[0] + '_' + img_name.split('-')[1] + '.png')  # GoPro
                        save_img_path = osp.join(self.opt['path']['visualization'], dataset_name, img_name + '.png')  # HIDE
                        imwrite(sr_img_list[save_best], save_img_path)
                    else:
                        for h in range(n_heads):
                            save_img_path = osp.join(
                                self.opt['path']['visualization'], dataset_name,
                                f'{img_name}_h{h}.png')
                            imwrite(sr_img_list[h], save_img_path)
                        save_gt_img_path = osp.join(
                            self.opt['path']['visualization'], dataset_name,
                            f'{img_name}_gt.png')
                        imwrite(gt_img, save_gt_img_path)

                    # import matplotlib
                    # from basicsr.show_offset import get_offset_image
                    #
                    # offsets = visuals['offsets']
                    # blur_image = visuals['lq'].numpy()[0]
                    # blur_image = np.transpose(blur_image, (1, 2, 0))
                    #
                    # save_blur_kernel_name = osp.join(self.opt['path']['visualization'], dataset_name, f'blur_kernel_{img_name}.png')
                    # all_offset = [offsets['offset'].cpu().numpy()]  # x-u,y-v
                    # image = get_offset_image(image=blur_image, all_offset=all_offset, deform_kernel_size=5, position_shift=[0, 0, 0, 0, 0], step=[20, 20], plot_area=1)
                    # matplotlib.image.imsave(save_blur_kernel_name, image.clip(0, 1))
                    # #
                    # # save_inverse_kernel_name = osp.join(self.opt['path']['visualization'], dataset_name, f'inverse_kernel_{img_name}.png')
                    # # all_offset = [offsets['inverse_offset'].cpu().numpy()]  # x-u,y-v
                    # # image = get_offset_image(image=blur_image, all_offset=all_offset, deform_kernel_size=7, position_shift=[0, 0, 0, 0, 0, 0, 0], step=[20, 20], plot_area=1)
                    # # matplotlib.image.imsave(save_inverse_kernel_name, image.clip(0, 1))
                    #
                    # lq_4 = F.interpolate(visuals['lq'], scale_factor=0.25, mode='bilinear')
                    # gt_4 = F.interpolate(visuals['gt'], scale_factor=0.25, mode='bilinear')
                    #
                    # reblur_image = self.reblur(None, gt_4.cuda(), visuals['offsets']['offset'], visuals['offsets']['weight']).cpu()
                    # save_reblur_image_name = osp.join(self.opt['path']['visualization'], dataset_name, 'reblur_image', f'{img_name}.png')
                    # reblur_image = tensor2img(reblur_image, rgb2bgr=rgb2bgr)
                    # imwrite(reblur_image, save_reblur_image_name)
                    #
                    # save_gtblur_image_name = osp.join(self.opt['path']['visualization'], dataset_name, 'gtblur_image', f'{img_name}.png')
                    # lq_4 = tensor2img(lq_4, rgb2bgr=rgb2bgr)
                    # imwrite(lq_4, save_gtblur_image_name)

            cnt += 1
            if rank == 0:
                for _ in range(world_size):
                    pbar.update(1)
                    pbar.set_description(f'Test {img_name}')
        if rank == 0:
            pbar.close()

        # current_metric = 0.
        collected_metrics = OrderedDict()
        if with_metrics:
            for metric in self.metric_results.keys():
                collected_metrics[metric] = torch.tensor(self.metric_results[metric]).float().to(self.device)
            collected_metrics['cnt'] = torch.tensor(cnt).float().to(self.device)

            self.collected_metrics = collected_metrics

        keys = []
        metrics = []

        vec_keys = []
        vec_metrics = []
        for name, value in self.collected_metrics.items():
            if value.dim() > 0:
                vec_keys.append(name)
                vec_metrics.append(value)
            else:
                keys.append(name)
                metrics.append(value)
        metrics = torch.stack(metrics, 0)
        vec_metrics = torch.stack(vec_metrics, 0)
        torch.distributed.reduce(metrics, dst=0)
        torch.distributed.reduce(vec_metrics, dst=0)
        if self.opt['rank'] == 0:
            metrics_dict = {}
            cnt = 0
            for key, metric in zip(keys, metrics):
                if key == 'cnt':
                    cnt = float(metric)
                    continue
                metrics_dict[key] = float(metric)

            for key, metric in zip(vec_keys, vec_metrics):
                metrics_dict[key] = metric.cpu().numpy()

            for key in metrics_dict:
                metrics_dict[key] /= cnt

            self._log_validation_metric_values(current_iter, dataloader.dataset.opt['name'],
                                               tb_logger, metrics_dict)
        return 0.

    def nondist_validation(self, *args, **kwargs):
        logger = get_root_logger()
        logger.warning('nondist_validation is not implemented. Run dist_validation.')
        self.dist_validation(*args, **kwargs)

    def _log_validation_metric_values(self, current_iter, dataset_name,
                                      tb_logger, metric_dict):
        log_str = f'Validation {dataset_name}, \t'
        for metric, value in metric_dict.items():
            if isinstance(value, np.ndarray):
                s = ', '.join([f'{v:.4f}' for v in value])
                log_str += f'\t # {metric}: [{s}]'
            else:
                log_str += f'\t # {metric}: {value:.4f}'
        logger = get_root_logger()
        logger.info(log_str)

        log_dict = OrderedDict()
        # for name, value in loss_dict.items():
        for metric, value in metric_dict.items():
            log_dict[f'm_{metric}'] = value

        self.log_dict = log_dict

    def get_current_visuals(self):
        out_dict = OrderedDict()
        out_dict['lq'] = self.lq.detach().cpu()
        out_dict['result'] = self.output.detach().cpu().transpose(0, 1)
        out_dict['offsets'] = self.offsets
        if hasattr(self, 'gt'):
            out_dict['gt'] = self.gt.detach().cpu()
        return out_dict

    def save(self, epoch, current_iter):
        self.save_network(self.net_g, 'net_g', current_iter)
        self.save_training_state(epoch, current_iter)
